#include <stdio.h>

int main(){


  ui_left();
  ui_right();
  ui_up();
  ui_down();
  ui_power();
  ui_hover();

  return 0;
}

int ui_left(){

  printf("turning left\n");

  return 0;
}
